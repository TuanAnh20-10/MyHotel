package com.xinchaongaymoi.hotelbookingapp.model

data class Booking(
    val id: String = "",
    val checkInDate: String = "",
    val checkOutDate: String = "",
    val roomId: String = "",
    val totalPrice: Int = 0
)
