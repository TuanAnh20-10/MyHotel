package com.xinchaongaymoi.hotelbookingapp.activity

import android.R
import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.xinchaongaymoi.hotelbookingapp.adapter.ImageSliderAdapter
import com.xinchaongaymoi.hotelbookingapp.databinding.ActivityBookRoomBinding

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class HotelBookingActivity: AppCompatActivity() {
    private lateinit var binding: ActivityBookRoomBinding
    private lateinit var database: DatabaseReference
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookRoomBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Khởi tạo tham chiếu Firebase Realtime Database
        database = FirebaseDatabase.getInstance().getReference("rooms")

        // Nhận ROOM_ID từ Intent
        val roomId = intent.getStringExtra("ROOM_ID")
        if (!roomId.isNullOrEmpty()) {
            // Hiển thị ROOM_ID hoặc dùng nó để thực hiện logic đặt phòng
            Toast.makeText(this, "Booking Room ID: $roomId", Toast.LENGTH_SHORT).show()
            fetchRoomDetails(roomId)
        } else {
            Toast.makeText(this, "Room ID not found!", Toast.LENGTH_SHORT).show()
        }

        // Đặt sự kiện cho các ô ngày để mở DatePickerDialog
        binding.tvCheckInDate.setOnClickListener { showDatePickerDialog(true) }
        binding.tvCheckOutDate.setOnClickListener { showDatePickerDialog(false) }

        // Sự kiện cho nút Book Now
        binding.bntBook.setOnClickListener {
            bookRoom(roomId)
        }
    }

    private fun showDatePickerDialog(isCheckIn: Boolean) {
        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            val formattedDate = formatDate(year, monthOfYear, dayOfMonth)
            if (isCheckIn) {
                binding.tvCheckInDate.text = formattedDate
            } else {
                binding.tvCheckOutDate.text = formattedDate
            }
        }

        val datePickerDialog = DatePickerDialog(
            this,
            dateSetListener,
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    private fun formatDate(year: Int, month: Int, day: Int): String {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, day)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }

    private fun fetchRoomDetails(roomId: String) {
        database.child(roomId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val roomName = snapshot.child("roomName").getValue(String::class.java)
                    val pricePerNight = snapshot.child("pricePerNight").getValue(Int::class.java)
                    val maxGuests = snapshot.child("maxGuests").getValue(Int::class.java) ?: 0


                    // Hiển thị thông tin lên giao diện
                    binding.tvRoomName.text = roomName ?: "Unknown Room"
                    binding.tvRoomPrice.text = "Price: $${pricePerNight ?: 0}/night"

                    // Lấy danh sách URL hình ảnh từ trường "images"
                    val imageList = snapshot.child("images").children.mapNotNull { it.value?.toString() }
                    // Gán adapter cho ViewPager2
                    val adapter = ImageSliderAdapter(imageList)
                    binding.viewPagerImages.adapter = adapter

                    // Giới hạn số lượng khách trong Spinner
                    val guestsArray = (1..maxGuests).toList().map { it.toString() }.toTypedArray()
                    val spinnerAdapter = ArrayAdapter(this@HotelBookingActivity, R.layout.simple_spinner_item, guestsArray)
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.spinnerGuests.adapter = spinnerAdapter

                } else {
                    Toast.makeText(this@HotelBookingActivity, "Room not found!", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseError", error.message)
                Toast.makeText(this@HotelBookingActivity, "Failed to load room details!", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun bookRoom(roomId: String?) {
        val checkInDate = binding.tvCheckInDate.text.toString()
        val checkOutDate = binding.tvCheckOutDate.text.toString()
        val userId = "user_123" // Để dễ dàng thay đổi sau này thành ID người dùng thực tế
        val currentDate = SimpleDateFormat("hh:mm a dd/MM/yyyy", Locale.getDefault()).format(Calendar.getInstance().time)
        val pricePerNight = 100 // Đặt giá mỗi đêm (bạn có thể lấy từ Firebase nếu có)

        if (roomId != null && checkInDate.isNotEmpty() && checkOutDate.isNotEmpty()) {
            // Tính số ngày thuê
            val diffInMillis = Calendar.getInstance().apply {
                setTime(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(checkOutDate))
            }.timeInMillis - Calendar.getInstance().apply {
                setTime(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(checkInDate))
            }.timeInMillis

            val totalDays = diffInMillis / (1000 * 60 * 60 * 24) // Tính số ngày
            val totalPrice = totalDays * pricePerNight

            // Tạo ID Booking tự động
            val bookingId = "booking${UUID.randomUUID()}"

            // Tạo đối tượng Booking
            val bookingData = hashMapOf(
                "checkInDate" to checkInDate,
                "checkOutDate" to checkOutDate,
                "createdAt" to currentDate,
                "id" to bookingId,
                "roomId" to roomId,
                "status" to "pending",
                "totalPrice" to totalPrice,
                "userId" to userId
            )

            // Thêm dữ liệu vào Firebase Realtime Database
            val bookingRef = FirebaseDatabase.getInstance().getReference("Booking")
            bookingRef.push().setValue(bookingData).addOnCompleteListener {
                if (it.isSuccessful) {
                    Toast.makeText(this, "Booking successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to make booking.", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
        }
    }
}