package com.xinchaongaymoi.hotelbookingapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.xinchaongaymoi.hotelbookingapp.model.Booking

class BookedRoomsAdapter(
    private val bookedRooms: List<Booking>,
    private val onCancelClickListener: (String) -> Unit
) : RecyclerView.Adapter<BookedRoomsAdapter.BookedRoomViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookedRoomViewHolder {
        val binding = ItemBookedRoomBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BookedRoomViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BookedRoomViewHolder, position: Int) {
        val booking = bookedRooms[position]
        holder.bind(booking)
    }

    override fun getItemCount(): Int = bookedRooms.size

    inner class BookedRoomViewHolder(private val binding: ItemBookedRoomBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(booking: Booking) {
            binding.tvRoomName.text = booking.roomId
            binding.tvCheckInDate.text = "Check-in: ${booking.checkInDate}"
            binding.tvCheckOutDate.text = "Check-out: ${booking.checkOutDate}"
            binding.tvTotalPrice.text = "Total: $${booking.totalPrice}"

            // Xử lý sự kiện khi nhấn nút hủy
            binding.btnCancel.setOnClickListener {
                onCancelClickListener(booking.id)
            }
        }
    }
}
