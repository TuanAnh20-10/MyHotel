package com.xinchaongaymoi.hotelbookingapp.activity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.xinchaongaymoi.hotelbookingapp.adapter.BookedRoomsAdapter
import com.xinchaongaymoi.hotelbookingapp.databinding.ActivityBookedRoomsBinding
import com.xinchaongaymoi.hotelbookingapp.model.Booking

class BookedRoomsActivity: AppCompatActivity() {
    private lateinit var binding: ActivityBookedRoomsBinding
    private lateinit var database: DatabaseReference
    private lateinit var adapter: BookedRoomsAdapter
    private val bookedRoomsList = mutableListOf<Booking>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookedRoomsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Khởi tạo Firebase
        database = FirebaseDatabase.getInstance().getReference("Booking")

        // Khởi tạo Adapter cho RecyclerView
        adapter = BookedRoomsAdapter(bookedRoomsList) { bookingId ->
            cancelBooking(bookingId)
        }

        // Cài đặt RecyclerView
        binding.recyclerViewBookedRooms.adapter = adapter

        // Lấy danh sách phòng đã đặt từ Firebase
        fetchBookedRooms()
    }

    private fun fetchBookedRooms() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                bookedRoomsList.clear()
                for (bookingSnapshot in snapshot.children) {
                    val booking = bookingSnapshot.getValue(Booking::class.java)
                    if (booking != null) {
                        bookedRoomsList.add(booking)
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@BookedRoomsActivity, "Failed to load bookings", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun cancelBooking(bookingId: String) {
        // Xóa dữ liệu trong Firebase khi hủy booking
        val bookingRef = database.child(bookingId)
        bookingRef.removeValue().addOnCompleteListener {
            if (it.isSuccessful) {
                Toast.makeText(this, "Booking canceled successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to cancel booking", Toast.LENGTH_SHORT).show()
            }
        }
    }
}